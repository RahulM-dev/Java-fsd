package com;

public class TypeCasting {
	public static void main(String args[]) {
		
		int num = 10;
		float num1 = num;
		System.out.println(num1); // Implicit type casting 
		
		//But if we want to store a float in integer then explicitly we have to typecast
		
		float num2 = 20.43f;
		int num3 = (int)num2;
		System.out.println(num3);
		
	}
}
