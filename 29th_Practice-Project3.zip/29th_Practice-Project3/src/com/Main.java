package com;

public class Main {

	public static void main(String[] args) {
		
		Data nd = new Data();
		
		Thread1 t1 = new Thread1(nd);
		Thread2 t2 = new Thread2(nd);
		
		
		t1.start();
		t2.start();

	}

}
