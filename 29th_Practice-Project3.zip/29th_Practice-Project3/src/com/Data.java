package com;

public class Data {
		public int id = 0;
}
