package com;

public class Thread2 extends Thread{
	
	Data d;
	Thread2(Data d){
		this.d = d;
	}
	
	public void run() {
		synchronized(d) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			
		}
		this.d.id = 10;
		d.notify();
		}
	}
}
