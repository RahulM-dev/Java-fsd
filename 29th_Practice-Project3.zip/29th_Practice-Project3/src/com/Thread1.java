package com;

public class Thread1 extends Thread{
	
	Data d;
	
	Thread1(Data d){
		this.d = d;
	}
		
	public void run() {
		
		synchronized(d){
			
			while(this.d.id != 10) {
				System.out.println("Waiting");
				try {
					d.wait();
				} catch (InterruptedException e) {
					
				}
					
			}
			System.out.println("Found the value");
			
		}
		
	}
}
