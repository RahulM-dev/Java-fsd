package com;

import java.util.Arrays;

public class MatrixMultiplication {
		
	MatrixMultiplication(){
		
		int first[][] = {{2, 53, 12},  {12, 22, 9},  {97, 12, 4}};
		int second[][] = {{12, 4, 9},  {7, 19, 14},  {5, 2, 9}};
		
		System.out.println("Array1: ");
		for(int[] a :  first) {
			System.out.println(Arrays.toString(a));
		}
		System.out.println("Array2: ");
		for(int[] a :  second) {
			System.out.println(Arrays.toString(a));
		}
		
		multiplyMatrix(first, second);
	}

	private void multiplyMatrix(int[][] a, int[][] b) {
		int result [][] = new int[a.length][b[0].length];
		for(int i = 0; i < a.length; i++) {
			
			for(int j = 0; j < b[0].length; j++) {
				
				for(int k = 0; k < a[0].length; k++) {
					
					result[i][j] = result[i][j] + a[i][k]*b[k][j];				
				}
			}
		}
		System.out.println();
		System.out.println("After multiplication the result matrix is: ");
		for(int[] x : result) {
			System.out.println(Arrays.toString(x));
		}
	}
	
	
}
