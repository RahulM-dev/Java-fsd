package com;

public class Main {
	
	public static void main(String []args) {
		
		
		//In the constructor defined the matrix multiplication defination and and called the method from it
		MatrixMultiplication mm = new MatrixMultiplication();
	
	}
	
}
