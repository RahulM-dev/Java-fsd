package com;

public class Main {

	public static void main(String[] args) {
		
		//The Method1 is static method. So it's linked to the class rather than the object. So to call this method we have to use the class name.
		FunctionCall.Method1(); 
		
		//The Method 2 is non-static method. So to call it we have to create an object.
		FunctionCall fc = new FunctionCall();
		fc.Method2();
		

	}

}
