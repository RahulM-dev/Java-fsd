package com;

public class FunctionCall {
	public static void Method1() {
		String str = "This is static method";
		System.out.println(str);
	}
	public void Method2() {
		String str = "This non-static method";
		System.out.println(str);
	}
}
