package com;

public class LinearSearchAlgo {
	int arr[];
	LinearSearchAlgo(int[] arr){
		this.arr = arr;
	}
	
	public int SearchElement(int num) {
		
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == num) {
				return i; 
			}
		}
		return -1;
	}
}
