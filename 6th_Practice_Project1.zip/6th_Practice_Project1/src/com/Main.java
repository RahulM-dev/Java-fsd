package com;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int arr[] = {21, 90, 33, 54, 55, 60};
		LinearSearchAlgo lsa = new LinearSearchAlgo(arr);
		
		System.out.println(Arrays.toString(arr));
		System.out.println("Enter the element to be searched");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		int result = lsa.SearchElement(choice);
		if(result == -1) 
			System.out.println("Number not found");
		else
			System.out.println("The number is found in " + result + " th position");
	}

}
