package com;

public class StringPracticeClass {
	public static void main(String args[]) {
		String str = new String("Hello");
		
		//StringBuffer
		StringBuffer sbf = new StringBuffer(str);
		System.out.println(sbf);
		
		// For reversing the string we can use the reverse() method
		sbf.reverse();
		System.out.println(sbf);
		
		
		//StringBuilder
		StringBuilder sbl = new StringBuilder(str);
		System.out.println(sbl);
		
		//For appending appending a string in the string builder we use the append() method.
		sbl.append(" World");
		System.out.println(sbl);
		
	}
}
