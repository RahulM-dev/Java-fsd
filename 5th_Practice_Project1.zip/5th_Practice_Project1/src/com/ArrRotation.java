package com;

import java.util.Arrays;

public class ArrRotation {

	public void demoArrayRotation(int a) {
		int[] arr = {4 , 14, 3, 35, 23, 24};
		int k=a;
		
		
		int n =arr.length;
		k=k%n; 
		
		System.out.println("Before rotating the array: "+ Arrays.toString(arr));
		
		int[] result=new int[arr.length]; 
		
		
		for(int i=0; i<k; i++)			
			result[i]=arr[n-k+i];
		
		int m=0;
		for(int j=k; j<n; j++)
			result[j]=arr[m++];
		
		System.out.println("After rotating the array " + k + " times: "+ Arrays.toString(result));

	}

}
