package com;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		ArrRotation ar = new ArrRotation();
		System.out.println("Enter how much time you want to rotate the array");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		ar.demoArrayRotation(n);

	}

}
