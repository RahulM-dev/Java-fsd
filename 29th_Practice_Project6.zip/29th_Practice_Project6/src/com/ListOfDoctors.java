package com;

import java.util.*;

public class ListOfDoctors {

	public Doctors findDoctor(int id) {
		
		List<Doctors> listDoctor = new ArrayList<Doctors>();
		
		listDoctor.add(new Doctors(1, "Mukul", 65));
		listDoctor.add(new Doctors(2, "Nilesh", 46));
		listDoctor.add(new Doctors(3, "Bipin", 67));
		listDoctor.add(new Doctors(4, "Paban", 37));
		listDoctor.add(new Doctors(5, "Kumar", 54));
		
		for(Doctors d : listDoctor) {
			if(d.getId() == id) {
				return d;
			}
		}
		return new Doctors(0, "None", 0);
		
	}
	
}
