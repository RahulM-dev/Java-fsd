package com;

public class Doctors {
		
	private String name;
	private int age;
	private int id;
	
	
	Doctors(int id, String name, int age){
		
		this.name = name;
		this.id = id;
		this.age = age;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getId() {
		return this.id;
	}
}
