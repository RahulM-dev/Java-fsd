package com;

public class Appointment {

	public void BookAppointment(int id) throws DoctorNotFound{
		
		ListOfDoctors lod = new ListOfDoctors();
		Doctors d = lod.findDoctor(id);
		
		
		if(d.getId() == 0) {
			throw new DoctorNotFound("Doctor Not Found");
		}
		else {
			System.out.println("Doctor Id: " + d.getId());
			System.out.println("Doctor Name: " + d.getName());
			System.out.println("Doctor Age: " + d.getAge());
			
		}
		
		
		
	}
}
