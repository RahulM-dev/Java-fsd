package com;

public class Thread1 extends Thread{
		
	public void run() {
		
		for(int i=1; i<= 10; i++) {
			System.out.println("Iteration: " + i);
			if(i == 5) {
				try {
					System.out.println("Thread is sleeping for 5 sec");
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					
				}
			}
		}
	}
}
