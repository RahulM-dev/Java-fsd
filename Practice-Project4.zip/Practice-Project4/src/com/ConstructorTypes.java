package com;

public class ConstructorTypes {
	ConstructorTypes(){
		System.out.println("This is No-Argument Constructor");
	}
	
	ConstructorTypes(String str){
		System.out.println(str);
		System.out.println("This is Parameterized Constructor");
	}
	
	//The below two constructor are parametrized overloaded constructor
	
	ConstructorTypes(int x, int y){
		System.out.println("The sum of two number is: " + (x+y));
	}
	ConstructorTypes(int x, int y , String str){
		System.out.println("The multiplication " + str + (x*y));
	}
}


