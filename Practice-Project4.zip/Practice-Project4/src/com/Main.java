package com;

public class Main {

	public static void main(String[] args) {
		ConstructorTypes ct = new ConstructorTypes();
		
		ConstructorTypes ct1 = new ConstructorTypes("Ok");
		
		ConstructorTypes ct3 = new ConstructorTypes(2, 3);
		
		ConstructorTypes ct4 = new ConstructorTypes(4, 5, "Value");

	}

}
