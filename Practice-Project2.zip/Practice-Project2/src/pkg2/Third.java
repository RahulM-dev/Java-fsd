package pkg2;

import pkg1.First;

public class Third {
	public void methodThird() {
		First f = new First();
	//System.out.println(f.z); // Not accessible because of the private access specifier
	//System.out.println(f.x); // Not accessible because of the default access specifier
	//System.out.println(f.a); // Not accessible beacause of the protected access specifier
	}
	
}
