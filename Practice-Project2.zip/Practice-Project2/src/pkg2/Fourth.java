package pkg2;

import pkg1.First;

public class Fourth extends First{
	public void fourthMethod() {
		//System.out.println(x); Not accessible because of the default accesss modifier	
		System.out.println(a);
	}
}
