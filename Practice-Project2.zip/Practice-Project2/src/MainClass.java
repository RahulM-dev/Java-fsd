import pkg1.First;
import pkg1.Second;
import pkg2.Fourth;

public class MainClass {

	public static void main(String[] args) {
		First f = new First();
	//	System.out.println(f.x); // x is not accessible because the access modifier for this is default so it's only accessible inside the same package
		
		System.out.println(f.y); // y is accessible because it's public
		
	//	System.out.println(f.z); // z is also not accessible because of the private access modifier
		
		Second s = new Second(); // It will print the x variable and because the default variable can be accessed in a class with in the same package
		
		f.printz(); // Accessible because of the private variable is called inside the same class
		
		Fourth fo = new Fourth();
		fo.fourthMethod();
		
	}

}
 