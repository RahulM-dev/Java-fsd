package pkg1;

public class First {
	int x = 10;
	public int y = 20; // The public member can be accessible from anywhere in the java program
	private int z = 30;
	protected int a = 40;
	
	public First() {
		this.z = 30;
	}
	public void printz() {
		System.out.println(z); // Accessible because the private variable z is in the same class
	}
}
