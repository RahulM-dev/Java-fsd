package pkg1;

public class Second {
	First f = new First();
	public Second(){
		First f = new First();
		System.out.println(f.x);
	}
	void printSecond() {
	//	System.out.println(f.z); // Error Because the z is a private variable so a private variable can only accessible in a class itself only even not in a class which is in the same package.
		
	}
}
