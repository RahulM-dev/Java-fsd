package com;

import java.util.Arrays;

public class DemoStackImplementation {
	
	int size;
	int[] stackContainer;
	int top = -1;
	DemoStackImplementation(int size){
		this.size = size;
		this.stackContainer = new int[size];
	}
	
	public void push(int val) {
		
		if(top == stackContainer.length-1) {
			System.out.println("Stack is full can't add element");
		}
		else {
			top++;
			stackContainer[top] = val;
//			System.out.println("Stack Elements: " + Arrays.toString(stackContainer));
		}
	}
	
	public void pop() {
		
		if(top == -1) {
			System.out.println("Stack is empty");
		}
		else {
			System.out.println();
			System.out.println(stackContainer[top]+ " has been deleted from the stack");
			top--;
		}
	}
	
	public void display() {
		System.out.println("The Elements in the stack are ");
		for(int i = top; i >= 0 ; i--) {
			System.out.print(stackContainer[i] + " ");
		}
		System.out.println();
	}
}
