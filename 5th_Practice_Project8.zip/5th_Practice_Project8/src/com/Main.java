package com;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int value = 0;
		boolean flag = true;
		System.out.println("Enter the size of the stack");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		DemoStackImplementation dsi = new DemoStackImplementation(size);
		
		System.out.println("Enter " + size + "elements");
		
		for(int i = 0; i < size; i++) {
			value = sc.nextInt();
			dsi.push(value);
		}
		


		while(flag) {
			System.out.println();
			System.out.println("Enter which operation you want to perform");
			System.out.println("1. ADD ELEMENT IN TO STACK");
			System.out.println("2. REMOVE ELEMENT FROM THE STACK");
			System.out.println("3. DISPLAY ELEMENT IN THE STACK");
			System.out.println("4. EXIT");
			int choice = sc.nextInt();
			
			switch(choice){
			case 1: 
				System.out.println("Enter the element");
				value = sc.nextInt(); 
				dsi.push(value);
				break;
			case 2: 
				dsi.pop();
				break;
			case 3:
				dsi.display();
				break;
			case 4: 
				System.out.println("Thank you");
				flag = false;
				break;
			}
			
		}
	
		
		

	}

}
