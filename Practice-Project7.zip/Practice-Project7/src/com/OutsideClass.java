package com;

public class OutsideClass {
	
	public static class Class1{	
		public void display1() {
			System.out.println("Static Class Member");
		}
	}
	
	public class Class2{	
		public void display2() {
			System.out.println("Non-Static Class Member");
		}
	}
	
	private class Class3{
		public void display3() {
			System.out.println("Non-Static Class Member(Private)");
		}
	}
}
