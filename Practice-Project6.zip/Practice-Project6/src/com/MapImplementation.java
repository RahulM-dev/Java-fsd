package com;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapImplementation {

	public static void main(String[] args) {
		Map<Integer, String> m = new HashMap<>();
		
		m.put(1, "Ram");
		m.put(2, "Rajesh");
		m.put(3, "Mohit");
		m.put(4, "Nikhil");
		m.put(5, "Subham");
		
		for(Entry<Integer, String> i : m.entrySet()) {
			System.out.println("Key: " + i.getKey() + "  " + "Value: " + i.getValue());
		}

	}

}
