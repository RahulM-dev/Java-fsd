package com.Bank.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Bank.Employee;
import com.Bank.Dao.EmployeeDao;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeDao employeeDao;
	
	@RequestMapping(value="/listEmployees", method=RequestMethod.GET)
	public String listEmployees(ModelMap model) {
		
		List<Employee> listOfEmployees = employeeDao.getEmployees();
		model.addAttribute("listOfEmployees", listOfEmployees);
		
		return "list-of-employees"; //It will be automatically converted to a list-of-employees.jsp page and check if it's present in the view folder or not because in the bean we have defined it
		
	}
	
	@RequestMapping(value="addEmployees", method=RequestMethod.POST)
	public String addTheEmployees(@RequestParam String name, @RequestParam float salary) {
		
		employeeDao.addEmployees(name, salary);
		
		return "add-Success";
	}
	
	@RequestMapping(value="/delEmployees", method=RequestMethod.POST)
	public String deleteTheEmployee(ModelMap model, @RequestParam int id) {
		
		employeeDao.deleteEmployee(id);
		model.addAttribute("delId", id);
		return "delete-Success";
	}
	
}









