package com.Bank.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.Bank.Employee;

public class EmployeeDao {
	
	JdbcTemplate template;
	public void setTemplate(JdbcTemplate template) {
		this.template = template;	
	}
	
	public List<Employee> getEmployees(){
		
		List<Employee> emps = template.query("SELECT * FROM Employees", new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Employee e = new Employee();
				e.seteId(rs.getLong("ID"));
				e.seteName(rs.getString("NAME"));
				e.seteSalary(rs.getBigDecimal("SALARY"));
				e.seteDateOfJoining(rs.getDate("DOJ"));
				
				return e;
			}

		});
		return emps;
	}
	public void addEmployees(String name, float salary) {
		template.update("INSERT INTO Employees (NAME, SALARY) VALUES (?, ?)", new Object[] {name, salary});
	}
	
	public void deleteEmployee(int id) {
		template.update("DELETE FROM Employees WHERE ID = ?", new Object[] {id});
	}
}








