package com.Bank;

import java.math.BigDecimal;
import java.util.Date;

public class Employee {
	
	private long eId;
	private String eName;
	private BigDecimal eSalary;
	private Date eDateOfJoining;
	
	public long geteId() {
		return eId;
	}
	public void seteId(long eId) {
		this.eId = eId;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public BigDecimal geteSalary() {
		return eSalary;
	}
	public void seteSalary(BigDecimal eSalary) {
		this.eSalary = eSalary;
	}
	public Date geteDateOfJoining() {
		return eDateOfJoining;
	}
	public void seteDateOfJoining(Date eDateOfJoining) {
		this.eDateOfJoining = eDateOfJoining;
	}
}
