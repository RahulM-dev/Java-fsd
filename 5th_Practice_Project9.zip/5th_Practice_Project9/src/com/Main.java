package com;

public class Main {

	public static void main(String[] args) {
		
		DemoQueueImplementation dqi = new DemoQueueImplementation(5);
		
		dqi.enqueue(21);
		dqi.enqueue(32);
		dqi.enqueue(90);
		
		dqi.display();
		dqi.dequeue();
		dqi.display();

	}

}
