package com;

public class DemoQueueImplementation {
	int size;
	int [] Queue;
	int front = -1;
	int rear = -1;
	DemoQueueImplementation(int size){
		this.size = size;
		this.Queue = new int[size];
	}
	
	void enqueue(int value) {
		
		if(isFull()) {
			System.out.println("Queue is full");
		}
		else {
			if(front == -1) {
				front = 0;
			}
			rear++;
			Queue[rear] = value;
			System.out.println(value + " has been added in the Queue");
		}
	}
	
	void dequeue() {
		if(rear == -1) {
			System.out.println("Queue is Empty");
		}
		else {
			System.out.println();
			System.out.println(Queue[front] + " has been deleted");
			front++;
		}
	}
	
	void display() {
		if(rear == -1) {
			System.out.println("Queue is Empty");
		}
		
		else {
			System.out.println("Items -> ");
			for(int i = front; i <= rear; i++) {
				System.out.print(Queue[i] + " ");
			}
		}
	}
	boolean isFull() {
		if(front - rear == size - 1) {
			return true;
		}
		return false;
	}
	
}
