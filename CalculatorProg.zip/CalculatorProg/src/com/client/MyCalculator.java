package com.client;


public class MyCalculator {
	void add(int num1, int num2) {
		System.out.println("The addition of the two numeber is: " + (num1+num2));
	}
	void sub(int num1, int num2) {
		System.out.println("The subtraction of the two numeber is: " + (num1-num2));
	}
	void mul(int num1, int num2) {
		System.out.println("The multiplication of the two numeber is: " + (num1*num2));
	}
	void div(int num1, int num2) {
		if(num2 == 0) {
			System.out.println("The number 2 cannot be zero in case of divison");
		}
		else {
			System.out.println("The divison of the two numeber is: " + (num1/num2));
		}
		
	}
}
