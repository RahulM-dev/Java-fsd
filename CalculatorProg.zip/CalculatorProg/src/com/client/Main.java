package com.client;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter which operations you want to perform");
		System.out.println("1. Addition");
		System.out.println("2. Subtraction");
		System.out.println("3. Multiplication");
		System.out.println("4. Division");
		int opt = sc.nextInt();
		MyCalculator c = new MyCalculator();
		
		System.out.println("Enter number 1");
		int num1 = sc.nextInt();
		System.out.println("Enter number 2");
		int num2 = sc.nextInt();
		
		//We can also switch case
		
		if(opt == 1) {
			c.add(num1, num2);
		}
		else if(opt == 2) {
			c.sub(num1, num2);
		}
		else if(opt == 3) {
			c.mul(num1, num2);
		}
		else if(opt == 4) {
			c.div(num1, num2);
		}
		else {
			System.out.println("Wrong input");
		}
		sc.close();
	}

}
