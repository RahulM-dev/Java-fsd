package com.myFolder;

public class Screensize {
	
	private int screenId;
	private String size;
	
	public Screensize() {
		
	}

	public int getScreenId() {
		return screenId;
	}

	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	
	
}
