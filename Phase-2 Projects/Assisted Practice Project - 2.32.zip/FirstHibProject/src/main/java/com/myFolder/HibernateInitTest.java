package com.myFolder;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class HibernateInitTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SessionFactory sessionFactory = null;
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		this.sessionFactory = HibernateUtil.getSessionFactory();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Session session;
		PrintWriter pw = response.getWriter();
		pw.print("<html><body>");
		
		session = sessionFactory.openSession();
		pw.println("Hibernate Session opened Successfully<br>");
		
		List<EProduct> products = session.createQuery("from EProduct").list();
		
		for(EProduct ep : products) {
			
			pw.print("Id= " + ep.getId() + "  ");
			pw.print("Name= " + ep.getName() + "  ");
			pw.print("Price= " + ep.getPrice() + "  ");
			pw.println(" <br>");
			
			List<Color> colors = ep.getColors();
			for(Color c : colors) {
				
				pw.print(c.getColorId() + " ");
				pw.print(c.getColorName());
				pw.print("<br><br>");
			}
			
		}
		
		
//		EProduct ep = new EProduct();
//		ep.setName("TestProduct");
//		
//		BigDecimal bd = new BigDecimal("25000.00");
//		ep.setPrice(bd);
//		session.save(ep);
		
		session.close();
		pw.println("Hibernate Session closed Successfully");
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
















