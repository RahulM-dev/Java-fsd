package com.myFolder;

public class OS {
	
	private int osId;
	private String name;
	
	public OS() {
		
	}

	public int getOsId() {
		return osId;
	}

	public void setOsId(int osId) {
		this.osId = osId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
