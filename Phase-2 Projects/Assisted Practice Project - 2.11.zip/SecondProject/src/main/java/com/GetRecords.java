package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetRecords extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		try {
			//The below line is used to import the JDBC Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			pw.write("Some Error happened with the driver");
		}
		try {
			//The below line is to create a connection object with authentication
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisAssistedProjectDB", "root", "password");
			
			//Create a statement object you want to execute
			Statement stmt = connection.createStatement();
			
			//Use the executeQuery method to execute the query
			ResultSet rs = stmt.executeQuery("SELECT * FROM Employees");
			pw.printf("<h1 style = 'text-align: center'>All the Records in the Employee Table</h1>");
			while(rs.next()) {
				pw.print("Employee ID= " + rs.getInt("EMP_ID") + "  ");
				pw.print("Employee Name= " + rs.getString("EMP_NAME") + "  ");
				pw.print("EMployee Age= " + rs.getInt("EMP_AGE") + "  ");
				pw.print("Employee Salary= " + rs.getFloat("EMP_SALARY"));
				pw.printf("<br>");
			}
			connection.close();
			
		} catch (SQLException e) {
			pw.write("Some Error happened with the Connection");
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
