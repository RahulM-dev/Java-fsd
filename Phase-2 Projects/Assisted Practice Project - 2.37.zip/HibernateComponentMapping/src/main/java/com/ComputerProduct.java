package com;

import java.math.BigDecimal;
import java.util.Date;

public class ComputerProduct {
	private int id;
	private String pName;
	private BigDecimal pPrice;
	private Date dateAdded;
	
	ProductParts productParts;
	
	public ProductParts getProductParts() {
		return productParts;
	}
	public void setProductParts(ProductParts productParts) {
		this.productParts = productParts;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public BigDecimal getpPrice() {
		return pPrice;
	}
	public void setpPrice(BigDecimal pPrice) {
		this.pPrice = pPrice;
	}
	public Date getDateAdded() {
		return dateAdded;
	}
	public void setDateAdded(Date dateAdded) {
		this.dateAdded = dateAdded;
	}
	
	
}
