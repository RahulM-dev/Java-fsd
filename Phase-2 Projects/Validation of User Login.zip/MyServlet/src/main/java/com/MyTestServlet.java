package com;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class MyTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String userId;
	String password;
	public void init(ServletConfig config) {
		
		//This init method is written to initialise the authentication details
		this.userId = config.getInitParameter("USERID");
		this.password = config.getInitParameter("PASSWORD");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("GET method is not defined");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userId = request.getParameter("userId");
		String password = request.getParameter("password");
		
		PrintWriter pw = response.getWriter();
		if(this.userId.equals(userId) && this.password.equals(password)) {
			pw.write("<b>UserId AND Password VERIFIED SUCCESSFULLY</b>");
		}
		else {
			pw.write("Not Verified!!! Try Again!!!");
		}
	}

}
