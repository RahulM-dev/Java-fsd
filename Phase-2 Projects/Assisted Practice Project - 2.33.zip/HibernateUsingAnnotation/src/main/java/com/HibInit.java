package com;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Eproduct;


public class HibInit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SessionFactory sessionFactory;
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		this.sessionFactory = HibUitl.getSessionFactory();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Session session;
		PrintWriter pw = response.getWriter();
		pw.print("<html><body>");
		
		session = sessionFactory.openSession();
		pw.println("Hibernate Session opened Successfully<br>");
		
		List<Eproduct> products = session.createQuery("from Eproduct").list();
		
		pw.print("<table border='1'><tr><td>ID</td><td>NAME</td><td>PRICE</td><td>DATE ADDED</td><td>COLOR ID</td><td>COLOR NAME</td></tr>");
		
		for(Eproduct ep : products) {
			
			pw.print("<tr><td>" + ep.getProductId() + "</td>");
			pw.print("<td>" + ep.getProductName() + "</td>");
			pw.print("<td>" + ep.getProductPrice() + "</td>");
			pw.print("<td>" + ep.getDateAdded() + "</td>");
			
			List<Color> colorOfProduct = ep.getColors();
			for(Color c : colorOfProduct) {
				pw.print("<td>" + c.getColorId() + "</td>");
				pw.print("<td>" + c.getColorName() + "</td>");
			}
			pw.print("</tr>");
		}
			pw.print("</table>");
		
		session.close();
		pw.println("Hibernate Session closed Successfully");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
