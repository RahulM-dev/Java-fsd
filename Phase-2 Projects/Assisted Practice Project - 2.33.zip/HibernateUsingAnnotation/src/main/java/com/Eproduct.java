package com;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="EProduct")
public class Eproduct {
	
	public Eproduct() {
		
	}
	@Id
	@GeneratedValue
	@Column(name="ID")
	private int productId;
	
	@Column(name="NAME")
	private String productName;
	
	@Column(name="PRICE")
	private BigDecimal productPrice;
	
	@Column(name="DATE_ADDED")
	private Date dateAdded;	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="PRODUCT_ID")
	List<Color> colors;
	
	public List<Color> getColors() {
		return colors;
	}
	public void setColors(List<Color> colors) {
		this.colors = colors;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public BigDecimal getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(BigDecimal productPrice) {
		this.productPrice = productPrice;
	}
	public Date getDateAdded() {
		return dateAdded;
	}
	public void setDateAdded(Date dateAdded) {
		this.dateAdded = dateAdded;
	}
}

