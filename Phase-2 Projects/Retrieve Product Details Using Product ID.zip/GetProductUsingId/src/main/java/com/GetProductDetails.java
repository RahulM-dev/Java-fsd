package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		int productId = Integer.parseInt(request.getParameter("productId"));
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisAssistedProjectDB", "root", "password");
			
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Products WHERE PRODUCT_ID = " + productId);
			
			pw.write("<h2 style = 'text-align:center'>Product Detail<h2><br><br><br>");
			
				while(rs.next()) {
					String pName = rs.getString("PRODUCT_NAME");
					int pQuantity = rs.getInt("PROD_QUANTITY");
					float pricePerUnit = rs.getFloat("PRICE_PERUNIT");
					pw.write("<table border = '1'>"); 
					pw.write("<tr><th>PROD_ID</th><th>PROD_NAME</th><th>PROD_QUANTITY</th><th>PRICE_PERUNIT</th></tr>");
					pw.write("<tr> <td> " + productId + "</td>");
					pw.write("<td> " + pName + "</td>");
					pw.write("<td> " + pQuantity + "</td>");
					pw.write("<td> " + pricePerUnit + "</td></tr></table>");
				}
			
			connection.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	}

}
