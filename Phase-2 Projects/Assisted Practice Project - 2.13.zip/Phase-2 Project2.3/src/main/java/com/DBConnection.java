package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	Connection connection = null;
	public DBConnection(String url, String user, String password) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		this.connection = DriverManager.getConnection(url, user, password);
		
	}
	public Connection getDBConnection() {
		return this.connection;
	}
	
	public void closeDBConnection() throws SQLException {
		this.connection.close();
	}
}
