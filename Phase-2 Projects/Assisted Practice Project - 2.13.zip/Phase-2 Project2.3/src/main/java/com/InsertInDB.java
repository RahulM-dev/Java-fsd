package com;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.Statement;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 
import com.*;
public class InsertInDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;
	public void init(ServletConfig config) {
		
		
		try {
			InputStream in = config.getServletContext().getResourceAsStream("/WEB-INF/database.properties");
			Properties props = new Properties();
			props.load(in);
			
			String url = props.getProperty("url");
			String userId = props.getProperty("userId");
			String password = props.getProperty("password");
			
			DBConnection dbCon = new DBConnection(url, userId, password);
			this.con = dbCon.getDBConnection();
			
			
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		try {
			Statement stmt = con.createStatement();
			
			int  rs = stmt.executeUpdate("INSERT INTO Employees(EMP_NAME, EMP_AGE, EMP_SALARY) VALUES ('Sushant', 24, 20000);");
			
			pw.printf("%s inserted successfully", rs);
			
			
		} catch (SQLException e) {
			pw.write("Something wrong happeded");
			e.printStackTrace();
		}
		pw.write("Done");
		pw.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
