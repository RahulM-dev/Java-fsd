package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

public class logoutPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		pw.write("<div style = \"text-align : right\">");
		pw.write("<a href = \"index.html\">Home</a> &nbsp; &nbsp;");
		pw.write("<a href = \"Dashboard\">Dashboard</a> &nbsp; &nbsp;");
		pw.write("<a href = \"login.html\">Login</a> &nbsp; &nbsp;");
		pw.write("</div><br><br>");
		pw.write("Logged out successfully.");
		HttpSession session = request.getSession(false);
		session.invalidate();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
