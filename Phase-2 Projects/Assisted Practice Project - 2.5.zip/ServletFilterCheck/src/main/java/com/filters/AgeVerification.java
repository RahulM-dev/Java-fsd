package com.filters;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpFilter;
import java.io.IOException;

//The all below imports are not valid because the javax package is renamed as jakarta
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;

public class AgeVerification extends HttpFilter implements Filter {
       
   
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		int age = Integer.parseInt(request.getParameter("age"));
		
		if(age >= 18)
			chain.doFilter(request, response);
		else
			response.getWriter().write("THE MINIMUM AGE MUST BE GREATER THAN 18 FOR THE DRIVING LISCENCE");
	}
}
