package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class DLNumberGeneration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter pw;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		pw = response.getWriter();
		pw.write("<center><h1>!!!!!!CONGRATULATIONS FOR YOUR NEW DL!!!!!!<h1></center>");
		Random r = new Random();
		int dlNo = (int) (r.nextFloat()*1000);
		pw.printf("Your DL number is: DL%d", dlNo);
	}

}
