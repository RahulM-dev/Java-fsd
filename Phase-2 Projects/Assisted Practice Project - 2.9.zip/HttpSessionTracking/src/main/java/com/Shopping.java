package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

public class Shopping extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		HttpSession session = request.getSession(false);
		if(session != null) {
			String uName = (String)session.getAttribute("uName");
			pw.print("Hello " + uName + " ,Shop as per you requirements");
		}
		else {
			pw.write("<p>Sorry  No Session found. Login again</p><br><br>");
			pw.write("<a href = 'login.html'> Login Page</a>");
			
		}
		
	}

}
