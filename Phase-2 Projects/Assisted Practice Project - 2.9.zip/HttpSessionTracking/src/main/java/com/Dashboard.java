package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

public class Dashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		String userName = request.getParameter("uName");
		String password = request.getParameter("password");
		
		if(userName.equals("root") && password.equals("password")) {
			
			HttpSession session = request.getSession(true);
			session.setAttribute("uName", userName);
			pw.write("<p>LOGIN SUCCESSFUL</p><br><br>");
			pw.write("<a href = 'Shopping'>Shopping Page</a>");
		}
		else {
			response.sendRedirect("login.html");
		}
	}
	

}
