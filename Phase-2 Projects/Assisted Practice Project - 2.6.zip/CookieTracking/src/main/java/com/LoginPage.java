package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("uname");
		String password = request.getParameter("password");
		if(userName.equals("Dark") && password.equals("password")) {
			Cookie c = new Cookie("userId", userName + "admin");
			c.setMaxAge(30);
			response.addCookie(c);
			response.sendRedirect("TestMainPage");
		}
		else {
			response.sendRedirect("TestMainPage");
		}
		
	}

}
