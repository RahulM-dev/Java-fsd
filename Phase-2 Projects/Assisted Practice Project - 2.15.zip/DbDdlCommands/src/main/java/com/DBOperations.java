package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;

public class DBOperations extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String dbName;
		PrintWriter pw = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		dbName = request.getParameter("dbName");
		if(dbName == null) {
			dbName = "Option2";
		}
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisAssistedProjectDB", "root", "password");
			Statement ps = connection.createStatement();
			pw.print("<h1 style = 'text-align:center'>Database Details</h1><br><br><br>");
			if(id == 1) {
				boolean result = ps.execute("CREATE DATABASE " + dbName);
				pw.print("<p>Database with the name " + dbName + " Created</p>");
			}
			
			else if(id == 2) {
				ResultSet rs = ps.executeQuery("SHOW DATABASES");
				pw.print("<table border = '1'>");
				pw.print("<tr><th>Databases</th></tr>");
				while(rs.next()) {
					pw.write("<tr><td>" + rs.getString("Database") + "</td></tr>");
				}
				pw.write("</table>");
			}
			else {
				boolean result = ps.execute("DROP DATABASE " + dbName);
				pw.print("<p>Database with the name " + dbName + " Dropped</p>");
			}
			connection.close();
		}
		 catch (ClassNotFoundException | SQLException e) {
			 if (e instanceof SQLException) {
			        pw.write("Some Error Happened! May Database With same name Exists" );
			        pw.print("<br><br>");
			        pw.write(e.getMessage());
			    } else {
			    	pw.write("Some Error Happened");
			    	pw.print("<br><br>");
			    	e.printStackTrace();
			    }
			 
		}
		
		
		
		
		
		
		
	}

}
