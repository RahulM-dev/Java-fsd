package com;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class InsertAmount extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection;
	public void init(ServletConfig config) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			InputStream in = config.getServletContext().getResourceAsStream("/WEB-INF/DatabaseDetails.properties");
			Properties props = new Properties();
			props.load(in);
			
			String url = props.getProperty("url");
			String userId = props.getProperty("userId");
			String password = props.getProperty("password");
			
			connection = DriverManager.getConnection(url, userId, password);
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	} 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		Float amount = Float.parseFloat(request.getParameter("amount"));
		try {
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM Employees WHERE EMP_SALARY > ?");
			ps.setFloat(1, amount);
			ResultSet results = ps.executeQuery();
			
			pw.write("<b>Employee Table</b><br>");
			pw.print("<table border = '1'>");
			pw.print("<tr> <th>Id</th> <th>Name</th> <th>Age</th> <th>Salary</th> </tr>");
			while(results.next()) {
				pw.print("<tr> <td>" + results.getInt("EMP_ID") + "</td>");
				pw.write("<td>" + results.getString("EMP_NAME") + "</td>");
				pw.write("<td>" + results.getInt("EMP_AGE") + "</td>");
				pw.write("<td>" + results.getFloat("EMP_SALARY") + "</td></tr>");
			}
			pw.printf("</table>");
		} catch (SQLException e) {
			pw.write("Error in GetBlock");
			e.printStackTrace();
		}
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
